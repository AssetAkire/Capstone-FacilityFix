import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String email;
  final String firstName;
  final String lastName;
  final String userRole; // 'admin', 'staff', 'tenant'
  final String buildingId;
  final String? unitId; // Optional for tenants
  final String? department; // Optional for staff
  final String status; // 'active', 'inactive', etc.
  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.uid,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.userRole,
    required this.buildingId,
    this.unitId,
    this.department,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  // Create UserModel from Firestore document
  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: data['uid'] ?? '',
      email: data['email'] ?? '',
      firstName: data['firstName'] ?? '',
      lastName: data['lastName'] ?? '',
      userRole: data['userRole'] ?? '',
      buildingId: data['buildingId'] ?? '',
      unitId: data['unitId'],
      department: data['department'],
      status: data['status'] ?? 'active',
      createdAt: (data['createdAt'] as Timestamp).toDate(),
      updatedAt: (data['updatedAt'] as Timestamp).toDate(),
    );
  }

  // Get full name
  String get fullName => '$firstName $lastName';

  // Check if user is admin
  bool get isAdmin => userRole.toLowerCase() == 'admin';

  // Check if user is staff
  bool get isStaff => userRole.toLowerCase() == 'staff';

  // Check if user is tenant
  bool get isTenant => userRole.toLowerCase() == 'tenant';
}
