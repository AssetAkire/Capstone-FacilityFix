import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../layout/facilityfix_layout.dart';

class InternalMaintenanceFormPage extends StatefulWidget {
  const InternalMaintenanceFormPage({super.key});

  @override
  State<InternalMaintenanceFormPage> createState() =>
      _InternalMaintenanceFormPageState();
}

class _InternalMaintenanceFormPageState
    extends State<InternalMaintenanceFormPage> {
  // -------------------- FORM & VALIDATION --------------------
  final _formKey = GlobalKey<FormState>();
  AutovalidateMode _autoMode = AutovalidateMode.disabled; // turn on after first submit

  // For consistent field heights
  static const double _kFieldHeight = 56;

  // -------------------- CONTROLLERS --------------------
  final _taskTitleController = TextEditingController();
  final _createdByController = TextEditingController();
  final _dateCreatedController = TextEditingController(); // read-only display

  final _descriptionController = TextEditingController();
  final _estimatedDurationController = TextEditingController();
  final _assignedStaffController = TextEditingController();
  final _remarksController = TextEditingController();

  final _startDateController = TextEditingController(); // read-only
  final _nextDueDateController = TextEditingController(); // read-only

  // -------------------- STATE --------------------
  String? _selectedTaskCode;
  String? _selectedPriority;
  String? _selectedStatus;
  String? _selectedLocation;
  String? _selectedRecurrence;
  String? _selectedDepartment;
  String? _selectedAdminNotification;
  String? _selectedStaffNotification;

  DateTime? _dateCreated;
  DateTime? _startDate;
  DateTime? _nextDueDate;

  // -------------------- NAV --------------------
  String? _getRoutePath(String routeKey) {
    final Map<String, String> pathMap = {
      'dashboard': '/dashboard',
      'user_users': '/user/users',
      'user_roles': '/user/roles',
      'work_maintenance': '/work/maintenance',
      'work_repair': '/work/repair',
      'calendar': '/calendar',
      'inventory_items': '/inventory/items',
      'inventory_request': '/inventory/request',
      'analytics': '/analytics',
      'announcement': '/announcement',
      'settings': '/settings',
    };
    return pathMap[routeKey];
  }

  void _handleLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Logout'),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                context.go('/');
              },
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  // -------------------- HELPERS --------------------
  // TODO: Replace with your auth/current user provider
  String _getCurrentUserName() => 'Michelle Reyes';

  String _fmtDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickDate({
    required DateTime initial,
    required ValueChanged<DateTime> onPick,
  }) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) onPick(picked);
  }

  void _initAutoFields() {
    // Created By (read-only)
    _createdByController.text = _getCurrentUserName();

    // Date Created (read-only; default to now)
    _dateCreated = DateTime.now();
    _dateCreatedController.text = _fmtDate(_dateCreated!);
  }

  // -------------------- VALIDATORS --------------------
  String? _req(String? v) =>
      (v == null || v.trim().isEmpty) ? 'Required' : null;

  String? _reqDropdown<T>(T? v) => (v == null) ? 'Required' : null;

  String? _durationValidator(String? v) {
    if (v == null || v.trim().isEmpty) return 'Required';
    final re = RegExp(r'^\d+\s*(min|mins|minutes|hr|hrs|hour|hours)$',
        caseSensitive: false);
    return re.hasMatch(v.trim())
        ? null
        : 'Use formats like "45 mins" or "3 hrs"';
  }

  // -------------------- INIT/DISPOSE --------------------
  @override
  void initState() {
    super.initState();
    _initAutoFields();
  }

  @override
  void dispose() {
    _taskTitleController.dispose();
    _createdByController.dispose();
    _dateCreatedController.dispose();
    _descriptionController.dispose();
    _estimatedDurationController.dispose();
    _assignedStaffController.dispose();
    _remarksController.dispose();
    _startDateController.dispose();
    _nextDueDateController.dispose();
    super.dispose();
  }

  // -------------------- ACTIONS --------------------
  void _saveDraft() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Draft saved successfully!')),
    );
  }

  Future<void> _onNext() async {
    // turn on real-time validation *after* first press
    setState(() => _autoMode = AutovalidateMode.onUserInteraction);

    if (!_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fix validation errors.')),
      );
      return;
    }

    // Build payload for the view page
    final id = (_selectedTaskCode ?? 'PM-NEW-${DateTime.now().millisecondsSinceEpoch}');
    final maintenance = <String, dynamic>{
      'id': id,
      'maintenanceType': 'Internal',
      'taskTitle': _taskTitleController.text.trim(),
      'taskCode': id,
      'createdBy': _createdByController.text.trim(),
      'dateCreated': _dateCreatedController.text,
      'priority': _selectedPriority,
      'status': _selectedStatus,
      'location': _selectedLocation,
      'description': _descriptionController.text.trim(),
      'recurrence': _selectedRecurrence,
      'estimatedDuration': _estimatedDurationController.text.trim(),
      'startDate': _startDateController.text,
      'nextDueDate': _nextDueDateController.text,
      'assigneeName': _assignedStaffController.text.trim(),
      'assigneeDept': _selectedDepartment,
      // sensible defaults
      'adminNotify': _selectedAdminNotification ??
          '1 week before, 3 days before, 1 day before',
      'staffNotify':
          _selectedStaffNotification ?? '3 days before, 1 day before',
      'tags': ['High-Turnover', 'Repair-Prone'],
    };

    // Go to the Internal View page (in edit mode so they can finalize)
    context.push('/work/maintenance/$id/internal?edit=1', extra: maintenance);
  }

  // -------------------- UI --------------------
  @override
  Widget build(BuildContext context) {
    return FacilityFixLayout(
      currentRoute: 'work_maintenance',
      onNavigate: (routeKey) {
        final routePath = _getRoutePath(routeKey);
        if (routePath != null) {
          context.go(routePath);
        } else if (routeKey == 'logout') {
          _handleLogout(context);
        }
      },
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          autovalidateMode: _autoMode,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ---------- HEADER ----------
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Work Orders",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 8),
                  //breadcrumb
                  Row(
                    children: [
                      TextButton(
                        onPressed: () => context.go('/dashboard'),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                        ),
                        child: const Text('Dashboard'),
                      ),
                      const Icon(Icons.chevron_right, color: Colors.grey, size: 16),
                      TextButton(
                        onPressed: () => context.go('/work/maintenance'),
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                        ),
                        child: const Text('Work Orders'),
                      ),
                      const Icon(Icons.chevron_right, color: Colors.grey, size: 16),
                      TextButton(
                        onPressed: null,
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                        ),
                        child: const Text('Maintenance Tasks'),
                      ),
                      
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 32),

              // ---------- FORM ----------
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withOpacity(0.03),
                        blurRadius: 10,
                        offset: const Offset(0, 2))
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.all(32.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== Basic Information =====
                      const Text(
                        "Basic Information",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Task Title
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _taskTitleController,
                                validator: _req,
                                decoration: _decoration('Enter Task Title'),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Task Code
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedTaskCode,
                                validator: _reqDropdown,
                                decoration: _decoration('Code Id'),
                                items: const ['PM-001', 'PM-002', 'PM-003']
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) => setState(
                                  () => _selectedTaskCode = v,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Created By (auto, read-only)
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _createdByController,
                                enabled: false, // not editable
                                decoration:
                                    _decoration('Automated Name').copyWith(
                                  disabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide:
                                        BorderSide(color: Colors.grey[300]!),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Date Created (editable with picker + validation)
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _dateCreatedController,
                                readOnly: true,                  // prevent typing, open picker instead
                                validator: _req,                 
                                onTap: () => _pickDate(
                                  initial: _dateCreated ?? DateTime.now(),
                                  onPick: (d) {
                                    setState(() {
                                      _dateCreated = d;
                                      _dateCreatedController.text = _fmtDate(d);
                                    });
                                  },
                                ),
                                decoration: _decoration('YYYY-MM-DD').copyWith(
                                  suffixIcon: const Icon(Icons.calendar_today, size: 18),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Priority
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedPriority,
                                validator: _reqDropdown,
                                decoration: _decoration('Select Priority...'),
                                items: const ['High', 'Medium', 'Low']
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) =>
                                    setState(() => _selectedPriority = v),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Status
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedStatus,
                                validator: _reqDropdown,
                                decoration: _decoration('Select Status...'),
                                items: const [
                                  'New',
                                  'In Progress',
                                  'Completed',
                                  'On Hold'
                                ]
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) =>
                                    setState(() => _selectedStatus = v),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 40),

                      // ===== Task Scope & Description =====
                      const Text(
                        "Task Scope & Description",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Location
                      _fieldLabel('Location / Area'),
                      _fieldBox(
                        child: DropdownButtonFormField<String>(
                          value: _selectedLocation,
                          validator: _reqDropdown,
                          decoration: _decoration('Select Location...'),
                          items: const [
                            'Swimming pool',
                            'Basketball Court',
                            'Gym',
                            'Parking area',
                            'Lobby',
                            'Elevators',
                            'Halls',
                            'Garden',
                            'Corridors',
                          ]
                              .map((v) =>
                                  DropdownMenuItem(value: v, child: Text(v)))
                              .toList(),
                          onChanged: (v) => setState(() {
                            _selectedLocation = v;
                          }),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // Description 
                      _fieldLabel('Description'),
                      TextFormField(
                        controller: _descriptionController,
                        validator: _req,
                        maxLines: 5,
                        decoration: _decoration('Enter Description....'),
                      ),

                      const SizedBox(height: 40),

                      // ===== Checklist / Task Steps =====
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            "Checklist / Task Steps",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                      'Add checklist item - Feature coming soon!'),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text("Add List"),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      _fieldBox(
                        child: TextFormField(
                          decoration: _decoration('Add List'),
                        ),
                      ),

                      const SizedBox(height: 40),

                      // ===== Recurrence & Schedule =====
                      const Text(
                        "Recurrence & Schedule",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Recurrence
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedRecurrence,
                                validator: _reqDropdown,
                                decoration: _decoration('Input'),
                                items: const [
                                  'Daily',
                                  'Weekly',
                                  'Monthly',
                                  'Quarterly',
                                  'Annually'
                                ]
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) =>
                                    setState(() => _selectedRecurrence = v),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Estimated Duration
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _estimatedDurationController,
                                validator: _durationValidator,
                                decoration:
                                    _decoration('e.g., 3 hrs / 45 mins'),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Start Date
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _startDateController,
                                validator: _req,
                                readOnly: true,
                                onTap: () => _pickDate(
                                  initial: _startDate ?? DateTime.now(),
                                  onPick: (d) {
                                    setState(() {
                                      _startDate = d;
                                      _startDateController.text = _fmtDate(d);
                                    });
                                  },
                                ),
                                decoration: _decoration('YYYY-MM-DD').copyWith(
                                  suffixIcon:
                                      const Icon(Icons.calendar_today, size: 18),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Next Due Date
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _nextDueDateController,
                                validator: _req,
                                readOnly: true,
                                onTap: () => _pickDate(
                                  initial: _nextDueDate ?? DateTime.now(),
                                  onPick: (d) {
                                    setState(() {
                                      _nextDueDate = d;
                                      _nextDueDateController.text = _fmtDate(d);
                                    });
                                  },
                                ),
                                decoration: _decoration('YYYY-MM-DD').copyWith(
                                  suffixIcon:
                                      const Icon(Icons.calendar_today, size: 18),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 40),
                      const Text("Assignment & Execution",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87)),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          // Department
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedDepartment,
                                validator: _reqDropdown,
                                decoration: _decoration('Select Department...'),
                                items: const [
                                  'Maintenance',
                                  'Engineering',
                                  'Facilities',
                                  'IT Support'
                                ]
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) =>
                                    setState(() => _selectedDepartment = v),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),

                          // Assigned Staff
                          Expanded(
                            child: _fieldBox(
                              child: TextFormField(
                                controller: _assignedStaffController,
                                validator: _req,
                                decoration: _decoration('Add Staff...'),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 40),
                      const Text("Attachments",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87)),
                      const SizedBox(height: 24),
                      Container(
                        height: 140,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          border:
                              Border.all(color: Colors.grey[300]!, width: 2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: InkWell(
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text(
                                      'File upload - Feature coming soon!')),
                            );
                          },
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.upload_outlined,
                                  size: 32, color: Colors.grey[400]),
                              const SizedBox(height: 8),
                              const Text("Drop files here or click to upload",
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500)),
                              const SizedBox(height: 4),
                              Text("PDF, PNG, JPG up to 10MB",
                                  style: TextStyle(
                                      fontSize: 12, color: Colors.grey[600])),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),
                      const Text("Remarks / Admin Notes",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87)),
                      const SizedBox(height: 24),

                      TextFormField(
                        controller: _remarksController,
                        maxLines: 5,
                        decoration: _decoration('Enter Description....'),
                      ),

                      const SizedBox(height: 40),
                      const Text("Notifications",
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87)),
                      const SizedBox(height: 24),

                      Row(
                        children: [
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedAdminNotification,
                                decoration: _decoration('Before due date'),
                                items: const [
                                  'Before due date',
                                  '1 day before',
                                  '3 days before',
                                  '1 week before'
                                ]
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) => setState(
                                    () => _selectedAdminNotification = v),
                              ),
                            ),
                          ),
                          const SizedBox(width: 24),
                          Expanded(
                            child: _fieldBox(
                              child: DropdownButtonFormField<String>(
                                value: _selectedStaffNotification,
                                decoration: _decoration('Before due date'),
                                items: const [
                                  'Before due date',
                                  '1 day before',
                                  '3 days before',
                                  '1 week before'
                                ]
                                    .map((v) => DropdownMenuItem(
                                          value: v,
                                          child: Text(v),
                                        ))
                                    .toList(),
                                onChanged: (v) => setState(
                                    () => _selectedStaffNotification = v),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 40),

                      // ===== Actions =====
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          OutlinedButton(
                            onPressed: _saveDraft,
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.grey),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 16),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.save_outlined,
                                    size: 18, color: Colors.grey[700]),
                                const SizedBox(width: 8),
                                Text("Save Draft",
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.grey[700])),
                              ],
                            ),
                          ),
                          const SizedBox(width: 16),
                          ElevatedButton(
                            onPressed: _onNext, // VALIDATE then NAVIGATE
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 16),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text("Next",
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // -------------------- SMALL UI HELPERS --------------------
  InputDecoration _decoration(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.grey[400]),
        isDense: true,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blue),
        ),
      );

  Widget _fieldLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black87),
        ),
      );

  // Wrap inputs to enforce consistent heights
  Widget _fieldBox({required Widget child}) => SizedBox(
        height: _kFieldHeight,
        child: child,
      );
}
