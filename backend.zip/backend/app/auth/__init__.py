# This file makes the auth directory a Python package
